from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

def test_register_missing_first_name():
    driver = webdriver.Chrome()
    driver.get("https://facebook.com/signup")
    driver.find_element(By.NAME, "lastname").send_keys("Nguyen")
    driver.find_element(By.NAME, "reg_passwd__").send_keys("12345678")
    driver.find_element(By.NAME, "websubmit").click()
    assert "First name is required" in driver.page_source
    driver.quit()

def test_register_successful():
    driver = webdriver.Chrome()
    driver.get("https://facebook.com/signup")
    driver.find_element(By.NAME, "firstname").send_keys("An")
    driver.find_element(By.NAME, "lastname").send_keys("Nguyen")
    driver.find_element(By.NAME, "reg_email__").send_keys("an@example.com")
    driver.find_element(By.NAME, "reg_passwd__").send_keys("12345678")
    driver.find_element(By.NAME, "websubmit").click()
    assert "Welcome" in driver.page_source
    driver.quit()
