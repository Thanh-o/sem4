import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SignUpScreen(),
    );
  }
}

class SignUpScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Facebook Sign Up")),
      body: Form(
        key: _formKey,
        child: ListView(padding: EdgeInsets.all(16), children: [
          Text("Create a new account", style: TextStyle(fontSize: 22)),
          TextFormField(
            decoration: InputDecoration(labelText: "First name"),
            validator: (val) => val!.isEmpty ? "Required" : null,
          ),
          TextFormField(
            decoration: InputDecoration(labelText: "Surname"),
            validator: (val) => val!.isEmpty ? "Required" : null,
          ),
          Text("Date of Birth"),
          Row(children: [
            Expanded(child: DropdownButtonFormField(items: [], onChanged: (val) {},)),
            Expanded(child: DropdownButtonFormField(items: [], onChanged: (val) {},)),
            Expanded(child: DropdownButtonFormField(items: [], onChanged: (val) {},)),
          ]),
          Text("Gender"),
          Row(children: [
            Expanded(child: RadioListTile(value: "F", groupValue: "G", onChanged: (val) {}, title: Text("Female"))),
            Expanded(child: RadioListTile(value: "M", groupValue: "G", onChanged: (val) {}, title: Text("Male"))),
            Expanded(child: RadioListTile(value: "C", groupValue: "G", onChanged: (val) {}, title: Text("Custom"))),
          ]),
          TextFormField(
            decoration: InputDecoration(labelText: "Mobile number or email"),
            validator: (val) => val!.contains("@") ? null : "Invalid email",
          ),
          TextFormField(
            decoration: InputDecoration(labelText: "New password"),
            obscureText: true,
            validator: (val) => val!.length < 6 ? "Too short" : null,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            child: Text("Sign Up"),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // Submit form
              }
            },
          )
        ]),
      ),
    );
  }
}
