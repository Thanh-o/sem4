/**
 * Rest layer.
 */
package com.mycompany.myapp.web.rest;
