/**
 * Application configuration.
 */
package com.mycompany.myapp.config;
