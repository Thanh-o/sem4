import { Component } from '@angular/core';

@Component({
  selector: 'jhi-docs',
  templateUrl: './docs.component.html',
  styleUrl: './docs.component.scss',
})
export default class DocsComponent {}
